#include <iostream>
#include <cmath>
#include <random>
using namespace std;

class SimpleNeuralNetwork {
private:
    // Weights
    double w1, w2, w3, w4;
    double v1, v2;
    
    // Bias
    double b1, b2, b3;
    
    // Learning rate
    const double learning_rate = 0.1;
    
    // Sigmoid activation function
    double sigmoid(double x) {
        return 1.0 / (1.0 + exp(-x));
    }
    
    // Sigmoid derivative for backpropagation
    double sigmoid_derivative(double x) {
        return x * (1 - x);
    }
    
    // Random number generator for initialization
    double random_weight() {
        static std::random_device rd;
        static std::mt19937 gen(rd());
        static std::uniform_real_distribution<> dis(-1.0, 1.0);
        return dis(gen);
    }
    
public:
    SimpleNeuralNetwork() {
        // Initialize weights with random values
        w1 = random_weight();
        w2 = random_weight();
        w3 = random_weight();
        w4 = random_weight();
        v1 = random_weight();
        v2 = random_weight();
        
        // Initialize biases
        b1 = random_weight();
        b2 = random_weight();
        b3 = random_weight();
    }
    
    double calculate(double x1, double x2) {
        // Hidden layer calculations
        double h1 = sigmoid(w1 * x1 + w2 * x2 + b1);
        double h2 = sigmoid(w3 * x1 + w4 * x2 + b2);
        
        // Output layer calculation
        double output = sigmoid(v1 * h1 + v2 * h2 + b3);
        
        return output;
    }
    
    void train() {
        const int iterations = 100000;
        const double target_error = 0.0001;
        
        for (int i = 0; i < iterations; i++) {
            double total_error = 0;
            
            // Training for all XOR cases
            for (int j = 0; j < 4; j++) {
                double x1 = j / 2;
                double x2 = j % 2;
                double target = (x1 != x2) ? 1.0 : 0.0;
                
                // Forward pass
                double h1 = sigmoid(w1 * x1 + w2 * x2 + b1);
                double h2 = sigmoid(w3 * x1 + w4 * x2 + b2);
                double output = sigmoid(v1 * h1 + v2 * h2 + b3);
                
                // Calculate error
                double error = target - output;
                total_error += error * error;
                
                // Backpropagation
                double delta_output = error * sigmoid_derivative(output);
                
                double delta_h1 = delta_output * v1 * sigmoid_derivative(h1);
                double delta_h2 = delta_output * v2 * sigmoid_derivative(h2);
                
                // Update weights and biases
                v1 += learning_rate * delta_output * h1;
                v2 += learning_rate * delta_output * h2;
                b3 += learning_rate * delta_output;
                
                w1 += learning_rate * delta_h1 * x1;
                w2 += learning_rate * delta_h1 * x2;
                w3 += learning_rate * delta_h2 * x1;
                w4 += learning_rate * delta_h2 * x2;
                
                b1 += learning_rate * delta_h1;
                b2 += learning_rate * delta_h2;
            }
            
            // Check if we've reached desired accuracy
            if (total_error < target_error) {
                cout << "Converged after " << i << " iterations\n";
                break;
            }
        }
    }
    
    // Function to get raw output (for debugging)
    double get_raw_output(double x1, double x2) {
        return calculate(x1, x2);
    }
};

int main() {
    SimpleNeuralNetwork nn;
    
    cout << "Training network...\n";
    nn.train();
    
    cout << "\nTesting XOR function:\n";
    cout << "0 XOR 0 = " << (nn.calculate(0, 0) >= 0.5 ? 1 : 0) 
         << " (Raw: " << nn.get_raw_output(0, 0) << ")" << endl;
    cout << "0 XOR 1 = " << (nn.calculate(0, 1) >= 0.5 ? 1 : 0)
         << " (Raw: " << nn.get_raw_output(0, 1) << ")" << endl;
    cout << "1 XOR 0 = " << (nn.calculate(1, 0) >= 0.5 ? 1 : 0)
         << " (Raw: " << nn.get_raw_output(1, 0) << ")" << endl;
    cout << "1 XOR 1 = " << (nn.calculate(1, 1) >= 0.5 ? 1 : 0)
         << " (Raw: " << nn.get_raw_output(1, 1) << ")" << endl;
    
    return 0;
}